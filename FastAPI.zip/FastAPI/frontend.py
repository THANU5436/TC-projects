from fastapi import FastAPI, File, UploadFile
import pandas as pd
import shutil
import os

app = FastAPI()

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.get("/")
def read_root():
    return {"message": "Welcome to the FastAPI CSV uploader!"}

@app.post("/uploadcsv/")
async def upload_csv(file: UploadFile = File(...)):
    if not file.filename.endswith('.csv'):
        return {"error": "Only CSV files are allowed!"}
    
    file_location = os.path.join(UPLOAD_DIR, file.filename)
    
    with open(file_location, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Read CSV using pandas
    df = pd.read_csv(file_location)
    
    # Do any processing here, for now return first 5 rows
    preview = df.head().to_dict(orient="records")
    
    return {
        "filename": file.filename,
        "preview": preview
    }
