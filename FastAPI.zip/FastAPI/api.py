from fastapi import FastAPI
from pydantic import BaseModel
import sqlite3

app = FastAPI()
def init_db():

    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users 
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

init_db()
class User(BaseModel):
    name: str
    email: str

@app.post("/users/")
def create_user(user: User):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (name, email) VALUES (?, ?)", (user.name, user.email))
    conn.commit()
    user_id = cursor.lastrowid
    conn.close()
    return {"id": user_id, "name": user.name, "email": user.email}

@app.get("/users/")
def get_users():
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, email FROM users")
    rows = cursor.fetchall()
    conn.close()
    users = [{"id": row[0], "name": row[1], "email": row[2]} for row in rows]
    return users
def init_db():
    conn = sqlite3.connect("...")
    cursor = conn.cursor()
    cursor.execute("""
        -- paste this full part --
    """)
    conn.commit()
    conn.close()